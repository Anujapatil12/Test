It is an Web Application based on jsp-servlet crud operations which includes both front-end and back-end.

About The Project:-
School Management System is an frond-end and back-end project based on Servlet(jsp, httpservlet).
This project has 2 Modules are as Follows:
1. Teacher
2. Student

Tools and Technologies used:-
Eclipse IDE
Maven 4.0
MySQL 8.0
Hibernate
Servlet
Java
